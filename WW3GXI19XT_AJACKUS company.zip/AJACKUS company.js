const apiUrl = 'http://localhost:5000/users'; // Mock API URL, replace with your backend API

// Sample data (replace with a real API call in a real app)
let users = [{
        id: 1,
        firstName: "John",
        lastName: "Doe",
        email: "john.doe@example.com",
        department: "Engineering"
    },
    {
        id: 2,
        firstName: "Jane",
        lastName: "Smith",
        email: "jane.smith@example.com",
        department: "Marketing"
    },
    {
        id: 3,
        firstName: "Sam",
        lastName: "Wilson",
        email: "sam.wilson@example.com",
        department: "HR"
    },
    {
        id: 4,
        firstName: "Emily",
        lastName: "Brown",
        email: "emily.brown@example.com",
        department: "Sales"
    },
];

document.addEventListener("DOMContentLoaded", () => {
    fetchUsers();

    // Event listeners for buttons
    document.getElementById("addUserBtn").addEventListener("click", showAddUserForm);
    document.getElementById("cancelAdd").addEventListener("click", cancelAddUserForm);
    document.getElementById("userForm").addEventListener("submit", handleUserFormSubmit);
});

// Fetch and display users from the API (simulated here with sample data)
function fetchUsers() {
    // In a real application, replace the following line with a fetch to your API
    // fetch(apiUrl)
    //     .then(response => response.json())
    //     .then(data => displayUsers(data))
    //     .catch(error => console.error("Error fetching users:", error));

    // Simulate delay and display users
    setTimeout(() => {
        displayUsers(users); // Using the sample data defined above
    }, 1000);
}

// Function to display the users in the table
function displayUsers(users) {
    const userList = document.getElementById('userList');
    userList.innerHTML = ''; // Clear existing list

    users.forEach(user => {
        const row = document.createElement('tr');

        // Create table cells
        const idCell = document.createElement('td');
        idCell.textContent = user.id;

        const firstNameCell = document.createElement('td');
        firstNameCell.textContent = user.firstName;

        const lastNameCell = document.createElement('td');
        lastNameCell.textContent = user.lastName;

        const emailCell = document.createElement('td');
        emailCell.textContent = user.email;

        const departmentCell = document.createElement('td');
        departmentCell.textContent = user.department;

        // Action buttons (Edit, Delete)
        const actionsCell = document.createElement('td');

        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.addEventListener('click', () => editUser(user.id));

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', () => deleteUser(user.id));

        actionsCell.appendChild(editButton);
        actionsCell.appendChild(deleteButton);

        // Append cells to row
        row.appendChild(idCell);
        row.appendChild(firstNameCell);
        row.appendChild(lastNameCell);
        row.appendChild(emailCell);
        row.appendChild(departmentCell);
        row.appendChild(actionsCell);

        // Append row to table body
        userList.appendChild(row);
    });
}

// Show Add User Form
function showAddUserForm() {
    document.getElementById("addUserForm").classList.remove("hidden");
}

// Hide Add User Form (Cancel)
function cancelAddUserForm() {
    document.getElementById("addUserForm").classList.add("hidden");
}

// Handle Add/Edit User form submission
function handleUserFormSubmit(event) {
    event.preventDefault();

    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const email = document.getElementById("email").value;
    const department = document.getElementById("department").value;

    const newUser = {
        id: Date.now(), // Generating a unique ID
        firstName,
        lastName,
        email,
        department
    };

    // Adding new user (replace with a POST request in real API)
    users.push(newUser);

    // Hide the form and clear the fields
    cancelAddUserForm();

    // Refresh the user list
    fetchUsers();
}

// Edit User
function editUser(userId) {
    const user = users.find(u => u.id === userId);
    if (user) {
        document.getElementById("firstName").value = user.firstName;
        document.getElementById("lastName").value = user.lastName;
        document.getElementById("email").value = user.email;
        document.getElementById("department").value = user.department;

        showAddUserForm();
    }
}

// Delete User
function deleteUser(userId) {
    users = users.filter(user => user.id !== userId);
    fetchUsers();
}